import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Http } from '@angular/http';

@Component({
    selector: 'kids',
    templateUrl: './kids.component.html',
    styleUrls: ['./kids.component.css']
})
export class KidsComponent implements OnInit {
    data: Object;
    todayDate = new Date();
    myMonth:number;
    myMonthString:string;
    myDay:string = "";
    todayDateFormatted:string = "";
    private urlGetKids:string = "http://www.goemobile.com/mobile/daycare/php/get_kids.php";
    constructor(private http: Http) { }
    //allKids:Array[];
    ngOnInit() {
        
        this.myMonth = (this.todayDate.getMonth() + 1);
        
        if(this.myMonth == 1 || this.myMonth == 2 || this.myMonth == 3 || this.myMonth == 4 || this.myMonth == 5 || this.myMonth == 6 || this.myMonth == 7 || this.myMonth == 8 || this.myMonth == 9){ 
            this.myMonthString = "0" + this.myMonth.toString();
        }

        this.myDay = this.todayDate.getDate().toString();
        if(this.myDay.length == 1){
            this.myDay = "0" + this.myDay;
        }
        
        this.todayDateFormatted = this.myMonth + "/" + this.myDay;
        this.http.get(this.urlGetKids)
        .subscribe(response => {
            this.data = response.json();
            }
        );

  }

}
