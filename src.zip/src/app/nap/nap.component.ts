import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nap',
  templateUrl: './nap.component.html',
  styleUrls: ['./nap.component.css']
})
export class NapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
